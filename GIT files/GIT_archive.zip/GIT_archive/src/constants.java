public class constants {
    public static final int BLOCK_SIZE = 50; // 50 since max tree diameter is (20*2 + 1) = 41
    public static final float STARTING_EXTENT = 0.4f;
    public static final int SEQUENTIAL_CUTOFF = 500;

}
