import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class block implements Comparable<block>{
    volatile float [][] values;
    private int blockNum;
    Lock lock = new ReentrantLock();    // lock used in the sequentialSum() method

    public block(int size, int num){
        values = new float[size][size]; // 50 by 50 float array of sunlight values
        blockNum = num;                 // unique block number
    }

    public void setValue(int y, int x, float val){
        values[y][x] = val;
    }

    public float getValue(int row, int col){
        float temp = values[row][col];
        values[row][col] = temp * 0.1f; // reduce sunlight cell to 10% of their original value
        return temp;
    }

    public int getBlockNum() {
        return blockNum;
    }

    // Allows blocks to be sorted by their block numbers when locking
    public int compareTo(block other){
        return Integer.compare(this.getBlockNum(), other.getBlockNum());
    }
}
