import java.io.*;
import java.util.StringTokenizer;

public class Test {
    public static void main(String args[]) throws FileNotFoundException, IOException{
        BufferedReader br = new BufferedReader(new FileReader("data/sample_input.txt"));
        StringBuilder sb = new StringBuilder();

        // load sunmap
        String[] dims = br.readLine().trim().split(" "); 	// Dimensions of landscape
        int dimx_test = 60;
        int dimy_test = 60;
        sb.append(dimx_test+" "+dimy_test+"\n");
        StringTokenizer sunDigits = new StringTokenizer(br.readLine());	// sunlight per square meter



        for(int x = 0; x < dimx_test; x++) {
            for (int y = 0; y < dimy_test; y++) {
                String token = sunDigits.nextToken();
                sb.append(token+" ");
            }
        }

        sb.append("\n");

        int numTrees_test = 2;

        //x y ext
        String tree1 = "20 20 0.4";
        String tree2 = "25 25 0.4";

        sb.append(numTrees_test+"\n");
        sb.append(tree1+"\n");
        sb.append(tree2+"\n");

        FileWriter fw = new FileWriter(new File("data/test_data.txt"));
        fw.append(sb.toString());
        fw.close();
    }
}
